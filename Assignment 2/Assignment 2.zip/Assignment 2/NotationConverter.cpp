// #include "NotationConverter.hpp"
#include <iostream>
#include <string>


// int main() {
//     NotationConverter nc;
//     const std::string s = "H W * R Q - /";

//     std::cout << nc.postfixToInfix(s) << std::endl;

//     return 0;
// }